/**************************************************
** File: A01_Code
** Date: 2023-07-18
** Auth: Ramkumar Rajanbabu
***************************************************
** Desc: Module 1 - Assignment 1
***************************************************
** Modification History
***************************************************
** Date			Author				Description 
** ----------	------------------  ---------------
** 2023-07-18	Ramkumar Rajanbabu	Completed A01Code.
**************************************************/

-- Run this Code to verify that Northwind and Pubs are installed
SELECT Name 
FROM SysDatabases;
GO